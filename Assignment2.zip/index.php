<?php
$host = 'localhost';
$data = '';
$user = 'root';
$pass = '';
$chrs = 'utf8mb4';
$attr = "mysql:host=$host;dbname=$data;charset=$chrs";
$opts =
    [
        PDO::ATTR_ERRMODE             => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE  => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES    => false,
    ];
try {
    $pdo = new PDO($attr, $user, $pass, $opts);
} catch (PDOException $e) {
    throw new PDOException($e->getMessage(), (int)$e->getCode());
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1);

$rows_per_page = 20;
$offset = ($page - 1) * $rows_per_page;

$query = $pdo->prepare("SELECT * FROM users LIMIT :limit OFFSET :offset");
$query->bindParam(':limit', $rows_per_page, PDO::PARAM_INT);
$query->bindParam(':offset', $offset, PDO::PARAM_INT);
$query->execute();

// to get the total pages to show all rows
$total_rows = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_pages = ceil($total_rows / $rows_per_page);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Assignment 2</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-flow: wrap column;
        }

        table {
            text-align: center;
        }

        td,
        th {
            padding: 5px;
        }
    </style>
</head>

<body>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Details</th>
        </tr>
        <?php while ($row = $query->fetch(PDO::FETCH_LAZY)): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['details']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <div>
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?php echo $i; ?>"> <?php echo $i; ?> </a>
        <?php endfor; ?>
    </div>
</body>

</html>