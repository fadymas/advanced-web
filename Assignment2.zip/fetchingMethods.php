<?php
$host = 'localhost';
$data = '';
$user = 'root';
$pass = '';
$chrs = 'utf8mb4';
$attr = "mysql:host=$host;dbname=$data;charset=$chrs";
$opts =
    [
        PDO::ATTR_ERRMODE             => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE  => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES    => false,
    ];
try {
    $pdo = new PDO($attr, $user, $pass, $opts);
} catch (PDOException $e) {
    throw new PDOException($e->getMessage(), (int)$e->getCode());
}
// fetchAll : fetch all data
$query = $pdo->query("SELECT * FROM users");
$rows = $query->fetchAll();
foreach ($rows as $row) {
    print_r($row);
    echo "<br>";
}


echo str_repeat("-", 100);
echo "<br>";

// fetch : fetch one row
$query = $pdo->query("SELECT * FROM users WHERE id = 1");
$row = $query->fetch();
print_r($row);
echo "<br>";


echo str_repeat("-", 100);
echo "<br>";


// FETCH_NUM : returns an indexed array 
$query = $pdo->query("SELECT * FROM users");
while ($row = $query->fetch(PDO::FETCH_NUM)) {
    print_r($row);
    echo "<br>";
}

echo str_repeat("-", 100);
echo "<br>";

// FETCH_ASSOC : Returns an associative array
$query = $pdo->query("SELECT * FROM users");
while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
    print_r($row);
    echo "<br>";
}

echo str_repeat("-", 100);
echo "<br>";

// FETCH_OBJ : Returns each row as an object
$query = $pdo->query("SELECT * FROM users");
while ($row = $query->fetch(PDO::FETCH_OBJ)) {
    print_r($row);
    echo "<br>";
}

echo str_repeat("-", 100);
echo "<br>";

// FETCH_BOTH : Returns both associative and numeric arrays
$query = $pdo->query("SELECT * FROM users");
while ($row = $query->fetch(PDO::FETCH_BOTH)) {
    echo $row[1] . " - " . $row['name'];
    echo "<br>";
}

echo str_repeat("-", 100);
echo "<br>";

// FETCH_LAZY : Returns data and allows accessing data as an associative or numeric array, object, or both.
$query = $pdo->query("SELECT * FROM users");
while ($row = $query->fetch(PDO::FETCH_LAZY)) {
    echo $row->name . "-" . $row[1] . "-" . $row['name'];
    echo "<br>";
}
